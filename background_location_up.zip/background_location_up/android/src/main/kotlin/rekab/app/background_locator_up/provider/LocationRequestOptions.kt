package rekab.app.background_locator_up.provider

class LocationRequestOptions(val interval: Long, val accuracy: Int, val distanceFilter: Float)